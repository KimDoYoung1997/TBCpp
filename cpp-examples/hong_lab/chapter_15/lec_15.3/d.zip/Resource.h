#pragma once

// Move semantics and Smart pointer
class Resource 
{
public:
    int *m_data=nullptr;
    unsigned m_length = 0;
public:
    Resource();
    Resource(int a);
    ~Resource();


};
